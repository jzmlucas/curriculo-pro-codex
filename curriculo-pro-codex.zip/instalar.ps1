$ErrorActionPreference = 'Stop'
$source = Join-Path $PSScriptRoot 'skills\curriculo'
if (-not (Test-Path (Join-Path $source 'SKILL.md'))) {
    throw "Não encontrei skills\curriculo\SKILL.md na pasta extraída."
}

$codexHome = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $env:USERPROFILE '.codex' }
$skillsHome = Join-Path $codexHome 'skills'
$destination = Join-Path $skillsHome 'curriculo'
New-Item -ItemType Directory -Force -Path $skillsHome | Out-Null

if (Test-Path $destination) {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $backup = Join-Path $skillsHome "curriculo.backup-$stamp"
    Move-Item -LiteralPath $destination -Destination $backup
    Write-Output "Versão anterior guardada em: $backup"
}

Copy-Item -LiteralPath $source -Destination $destination -Recurse
Write-Output "Skill instalada em: $destination"
Write-Output 'Abra uma nova conversa no Codex. Se necessário, reinicie o Codex para recarregar as Skills.'
