# Tooling inventory and dependency decisions

Last checked: 2026-10-21. Local availability can change; confirm before a real delivery.

## Already installed

| Tool | Use | Security/maintenance assessment |
|---|---|---|
| Codex `documents` skill | Create DOCX; render pages for visual inspection; optionally emit PDF | Bundled first-party workflow. Follow its render-and-inspect gate. |
| Codex `pdf` skill | Extract, render and inspect PDF; use `pdfinfo`/Poppler and PDF libraries | Bundled first-party workflow. Supports text extraction plus visual review. |
| `skill-creator` | Initialize and validate Codex Skills | Bundled official skill. Used for authoring conventions and validator. |
| Node + existing CVOptimizer packages | Existing application uses `docx`, `pdf-lib`, `pdfjs-dist`, Vitest | No packages copied or installed here. Existing lockfile is source of exact versions; audit before future upgrades. |
| Python standard library | Deterministic DOCX XML extraction and text checks | No external dependency; ZIP/XML parsers only. Do not execute DOCX macros or embedded content. |
| Poppler `pdfinfo`, `pdftoppm` | PDF page count and page rendering | Already present in bundled runtime; use for visual QA and page count. |
| PyMuPDF (`fitz`) | Optional PDF text extraction in shared auditor | Not confirmed installed. Script degrades clearly; `pdftotext` is an alternative. |
| LibreOffice | DOCX to PDF conversion | Not found on PATH at inventory time. Use bundled document workflow or install through an approved channel if later needed. |

## Researched open source candidates

- `python-docx` (`python-openxml/python-docx`): established MIT-licensed DOCX authoring library, but adding it is unnecessary because the installed Codex document workflow and existing CVOptimizer's `docx` package cover authoring. Source: https://github.com/python-openxml/python-docx and https://python-docx.readthedocs.io/.
- LibreOffice: mature open-source office suite with source under MPL/LGPL/GPL mix and official downloads. Its GitHub mirror is read-only and does not publish conventional GitHub releases; obtain binaries from libreoffice.org only. Not installed on PATH at inventory time. Source: https://www.libreoffice.org/ and https://github.com/LibreOffice/core.
- OCRmyPDF: actively maintained, open source (MPL-2.0), useful only for image-only scanned PDFs. It adds system dependencies and has a large attack surface; do not use for ordinary text resumes or run on untrusted PDFs without isolated current tooling. Optional, not required. Source: https://github.com/ocrmypdf/OCRmyPDF.
- Apache Tika: broad parser with a larger Java/runtime footprint; no need for this narrow local toolkit, so not adopted. Source: https://github.com/apache/tika.

No external dependencies were added. For any future addition, review upstream license, release activity, advisories, transitive dependencies, and necessity; pin versions and inspect lockfile changes.
