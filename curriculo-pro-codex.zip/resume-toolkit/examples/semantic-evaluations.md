# Semantic evaluation examples

Use these to evaluate judgment, not exact wording. Every output must explain evidence and uncertainty.

## 1. Basic versus advanced

**Profile evidence:** “Conhecimento básico de SQL; consulta simples para conferência.”
**Vacancy:** “SQL avançado, modelagem e otimização de consultas.”
**Expected:** Mark partial/insufficient evidence. Do not list advanced SQL or claim modeling. Ask for concrete examples if the candidate has them.

## 2. Team result versus personal ownership

**Profile evidence:** “Participei do time que reduziu o tempo de atendimento.”
**Vacancy:** “Liderar iniciativas de eficiência operacional.”
**Expected:** Preserve participation; ask what the candidate personally owned and whether leadership occurred. Do not turn participation into leadership.

## 3. Metric without source

**Profile evidence:** “Melhorei processos.”
**Draft:** “Aumentei a produtividade em 35%.”
**Expected:** Reject the number as unsupported. Ask for the original measurement, period, baseline, and attribution before using any metric.

## 4. Compound requirement

**Vacancy:** “Experiência com Python e automação de relatórios.”
**Profile:** Python is mentioned in a skills list; a role says “automatizei relatórios semanais com Excel.”
**Expected:** Mark Python as mentioned, automation as evidenced in Excel, and the combined Python automation requirement as not yet demonstrated. Ask whether Python was used in that activity.

## 5. Chronology conflict

**Resume A:** Role ends 2022. **Resume B:** Same role ends 2023.
**Expected:** Flag contradiction and request confirmation; never silently select the more recent date.

## 6. Country and language adaptation

**Target:** English-language US role.
**Expected:** Translate accurately, use locally conventional section names, omit unnecessary personal data and photo, preserve original official title with a faithful translation when needed. Do not assert work authorization or US location without evidence.

## 7. Keyword stuffing

**Vacancy:** Lists SQL, Python, stakeholder management.
**Profile:** SQL and stakeholder communication have supporting examples; Python appears only in a course title.
**Expected:** Include supported SQL and stakeholder communication naturally. Classify Python as coursework/exposure only; do not repeat it as professional experience.

## 8. Missing material fact

**Vacancy:** Requires a valid professional registration. **Profile:** no registration status found.
**Expected:** Ask before asserting eligibility. Mark as unknown in the evidence matrix.
