"""Deterministic, dependency-free resume quality checks."""
from __future__ import annotations

import argparse
import json
import re
import sys
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path


def normalize(text: str) -> str:
    return " ".join(text.casefold().split())


def audit_text(text: str, required_terms: list[str] | None = None) -> dict:
    findings: list[dict] = []
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if not lines:
        findings.append({"level": "error", "code": "empty_text", "message": "Nenhum texto extraído."})
    normalized = normalize(text)
    for term in required_terms or []:
        if normalize(term) not in normalized:
            findings.append({"level": "info", "code": "term_absent", "term": term})
    if re.search(r"\b(?:xx|lorem ipsum|TODO|TBD|\[inserir)\b", text, re.I):
        findings.append({"level": "warning", "code": "placeholder", "message": "Possível placeholder no documento."})
    if re.search(r"(?:R\$\s?\d[\d.,]*|\d+(?:[.,]\d+)?\s?%)", text):
        findings.append({"level": "info", "code": "quantified_claim_review", "message": "Revise se métricas e valores têm evidência."})
    return {"status": "fail" if any(f["level"] == "error" for f in findings) else "review", "non_empty_lines": len(lines), "findings": findings}


def extract_docx(path: Path) -> str:
    with zipfile.ZipFile(path) as archive:
        xml = ET.fromstring(archive.read("word/document.xml"))
    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    paragraphs = []
    for paragraph in xml.findall(".//w:p", ns):
        value = "".join(node.text or "" for node in paragraph.findall(".//w:t", ns))
        if value.strip():
            paragraphs.append(value)
    return "\n".join(paragraphs)


def read_pdf(path: Path) -> tuple[str, int | None]:
    try:
        import fitz  # PyMuPDF, optional; used only if already installed
        doc = fitz.open(path)
        return "\n".join(page.get_text("text", sort=True) for page in doc), len(doc)
    except ImportError:
        return "", None


def compare_versions(docx_text: str, pdf_text: str) -> dict:
    left, right = normalize(docx_text), normalize(pdf_text)
    if not right:
        return {"status": "unavailable", "message": "Extração de PDF indisponível: instale/configure PyMuPDF ou use pdftotext."}
    # Compare token sequence to tolerate line-wrap changes while preserving order.
    a, b = left.split(), right.split()
    common = 0
    cursor = 0
    for token in a:
        try:
            cursor = b.index(token, cursor) + 1
            common += 1
        except ValueError:
            pass
    coverage = common / max(1, len(a))
    return {"status": "pass" if coverage >= 0.98 else "review", "docx_tokens": len(a), "pdf_tokens": len(b), "ordered_token_coverage": round(coverage, 4)}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("file", type=Path)
    parser.add_argument("--terms", nargs="*", default=[])
    parser.add_argument("--compare", type=Path, help="PDF para comparar com DOCX")
    args = parser.parse_args()
    if not args.file.is_file():
        parser.error(f"Arquivo não encontrado: {args.file}")
    if args.file.suffix.casefold() == ".docx":
        text = extract_docx(args.file)
    elif args.file.suffix.casefold() == ".pdf":
        text, pages = read_pdf(args.file)
        if pages is not None:
            print(json.dumps({"pdf_pages": pages}, ensure_ascii=False))
    else:
        text = args.file.read_text(encoding="utf-8")
    result = {"file": str(args.file), "audit": audit_text(text, args.terms)}
    if args.compare:
        pdf_text, pages = read_pdf(args.compare)
        result["pdf_pages"] = pages
        result["comparison"] = compare_versions(text, pdf_text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 1 if result["audit"]["status"] == "fail" else 0


if __name__ == "__main__":
    sys.exit(main())
