import sys
import unittest
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parents[1] / "scripts"))
from audit_resume import audit_text, compare_versions, extract_docx


class AuditTests(unittest.TestCase):
    def test_empty_document_fails(self):
        self.assertEqual(audit_text("")["status"], "fail")

    def test_term_match_is_case_insensitive_and_whitespace_aware(self):
        result = audit_text("Experiência em\nPower BI", ["power bi"])
        self.assertFalse(any(f["code"] == "term_absent" for f in result["findings"]))

    def test_missing_term_is_reported_without_failing(self):
        result = audit_text("Analista de dados", ["Python"])
        self.assertEqual(result["status"], "review")
        self.assertEqual(result["findings"][0]["code"], "term_absent")

    def test_placeholders_and_metrics_are_flagged_for_human_review(self):
        codes = {f["code"] for f in audit_text("Aumentei vendas em 30%. TODO")["findings"]}
        self.assertIn("placeholder", codes)
        self.assertIn("quantified_claim_review", codes)

    def test_ordered_comparison_detects_missing_content(self):
        self.assertEqual(compare_versions("a b c", "a b c")["status"], "pass")
        self.assertEqual(compare_versions("a b c d e", "a e")["status"], "review")

    def test_docx_xml_extraction(self):
        path = Path(__file__).parents[1] / "sample-test.docx"
        try:
            xml = b'''<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>Resumo</w:t></w:r></w:p><w:p><w:r><w:t>Analista</w:t></w:r></w:p></w:body></w:document>'''
            with zipfile.ZipFile(path, "w") as archive:
                archive.writestr("word/document.xml", xml)
            self.assertEqual(extract_docx(path), "Resumo\nAnalista")
        finally:
            path.unlink(missing_ok=True)


if __name__ == "__main__":
    unittest.main()
